#include "customer.h"

Customer::Customer() {}
