#include "financialadvisor.h"

FinancialAdvisor::FinancialAdvisor() {}
