#include "database.h"

Database::Database() {}
